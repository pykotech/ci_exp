<?php
//can be choose expenses or expense model but $this->spend->insert("") looks neat to me
class Spend {
	function insert()
	}
?>