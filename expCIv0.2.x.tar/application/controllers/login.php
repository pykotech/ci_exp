<?php


class Login extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library('session','database','asseto');
	}
	public function start()
	{
		$this->load->view('header');
		echo "<form action=\"".site_url('login/login')."\" method=\"post\">";
		echo form_input();
		echo "</form>"

		$this->load->view('footer');
		
	}
	
	public function login()
	{
				$this->load->view('header');
		//check if form submit
		if($this->input->post("username")) {
			$query = $this->db->query("SELECT * FROM tbl_users WHERE username= '".$this->input->post('username')."' AND password = MD5(".$this->input->post('password').")");
			if($query->num_rows() > 0) {
				
				echo "loggedin ";
				
				$data = array('username' => $this->input->post('username'));
				
				$this->session->set_userdata($data);
				
			}
		}
		$this->load->view('footer');
	}
	
	public function logout() {
		$this->session
	}
}