<?php
//sets if on local or on website (pitchapie.com/xp)
//this is used for url.php
$l = false;
