﻿<?php
session_start();
session_destroy();

?><!doctype html><html><body>Logged out</body></html>
