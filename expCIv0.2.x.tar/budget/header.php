<!doctype html>
<html>
    <head><title><?php if(empty($title)) { echo "Pitchapie | A portal for #startup_pitch pitches for pitchers in Startup Weekend | Formerly known as Startup Weekend Online";
} else { echo $title . " | Pitchapie.com";}?></title>
            <meta charset="utf-8" />
	    <meta name="description" content="Pitchapie is about displaying startup pitches on this page so everyone can talk about it">
	  <meta name="keywords" content="#startup_pitch, pitches, startup pitches, startup weekend">
	 


            <!-- Our CSS stylesheet file -->
           <link rel="stylesheet" href="assets/css/styles.css" />

         <!--[if lt IE 9]>
         <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
         <![endif]-->
          </head>
<body>
<a href="http://www.pitchapie.com" title="Go back to Home page"><h1>Pitchapie!</h1></a>
