<?php
require('db.php');
$rs = $db->query("SELECT * FROM cash_on_hand ORDER BY modified DESC"); 
$cash = '';
if($rs)
{
	while($rows = $rs->fetch_object())
	{
        $cash .= "<h1>on hand" .$rows->modified . "</h1>";
        $cash .= "<strong>" . $rows->amount . "</strong><br />";
		$amount_on_hand = $rows->amount;
	}
}
else 
{
	$cash .= "No Records"; 

} 

$rs->free_result();

$rs = $db->query("SELECT * FROM cash_bank ORDER BY modified DESC"); 

if($rs)
{
	while($rows = $rs->fetch_object())
	{
        $cash .= "<br /><strong style=\"font-size:14px;\">on hand" .$rows->bank   . "</strong> : ";
		
		
		
        $cash .= "<strong>" . $rows->amount . "</strong><br />";
		if($rows->bank == 'bdo' || $rows->bank == 'BDO') {
			$amount_bdo = $rows->amount;
		}
		
		if($rows->bank == 'BPI') {
			$amount_bpi = $rows->amount;
		}
	}
}
else 
{
	$cash .= "No Records"; 

} 

?>
<!doctype html>
<html>
<head>
<title>Current Cash</title>
</head>
<body>
<form action="add_cash.php"> 

</strong color:blue>Current Cash: </strong><?php
if(isset($cash)) { echo $cash; } else { echo '0';}
?>
COH<input type="text" name="ccash" value="<?php if(isset($amount_on_hand)) echo $amount_on_hand; ?>" ><br />
BDO<input type="text" name="bdo" <?php if(isset($amount_bdo)) echo $amount_bdo; ?>><br />
BPI<input type="text" name="bpi" <?php if(isset($amount_bpi)) echo $amount_bpi; ?>><br />
<input type="submit" value="Set">

</form>