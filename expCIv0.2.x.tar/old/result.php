<?php
date_default_timezone_set('Asia/Manila');
/**
 *
 * @package expenses
 */
require_once('sec.php');
require_once('db.php');//has session_start()


$start = $_POST['date-start'];

$end = $_POST['date-end'];

$category = $_POST['category'];
if(!empty($start)) {
	$q = "SELECT * FROM expenses WHERE category='" . $category."' AND expensed >= '".$start."' AND expensed <= '".$end."'";
} else {
	$start = date('Y-m-d');
	$q = "SELECT * FROM expenses WHERE category='" . $category."' AND expensed >= '".$start."'";
		
}
echo $q;

	$res  = $db->query($q);
	echo "<table>";
	$total = 0;
	while($row  = $res->fetch_array())
			{
				echo "<tr><td>" .$row['category'] . "</td><td>".$row['item']."</td><td>" .$row['amount'] . "</td><td>".$row['expensed']."</td></tr>";
				$total += (int) $row['amount']; 
			} 

echo '<tr><td colspan="2">&nbsp;</td><td><strong>' .$total. '</strong></td>';
		echo "</table>";
		
?>