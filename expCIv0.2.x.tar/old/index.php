<?php
date_default_timezone_set('Asia/Manila');
/**
 *
 * @package expenses
 */
require_once('sec.php');
require_once('db.php');//has session_start()
?>

<?php

if(isset($_SESSION['unr']))
{

	$u = $_SESSION['unr']; 

	$usets = explode("|",$_SESSION['unr']);
	$uid = $usets[0];
	$timein = $usets[1];

	$d = date('Y-m-d'); /*date*/
        $sxteendaysago = date('Y-m-d',strtotime("16 days ago")); 
echo $sxteendaysago . ' to today (' . date('Y-m-d') . ')' ;
echo '<br>';
	$res = $db->query("SELECT * FROM expenses WHERE user_id = ".$uid ." AND id != '61' AND expensed >= '".$sxteendaysago."' ORDER BY expensed DESC "); //most recent.
	if($res) { 
		echo "<table>"; $go = true; 
	} else { $go = false;}

	if($go) { 
	
		while($row  = $res->fetch_array())
		{
			echo "<tr><td>" .$row['category'] . "</td><td>".$row['item']."</td><td>" .$row['amount'] . "</td><td>".$row['expensed']."</td></tr>";
$total += $row['amount'];
		
} 
echo "<tr><td colspan=\"3\">total</td><td>".$total."</td></tr>";
	echo "</table>";
	
	} 	else {
	
		echo "<tr><td>no records</td></tr></table>";
	}

}
?>

</div>
<div id="menu02"><a href="check.php">check expensed</a> | <a href="commuting.txt">commuting vs driving</a></div>
</body></html>
