<?php
date_default_timezone_set('Asia/Manila');
/**
 *
 * @package expenses
 */
require_once('sec.php');
require_once('db.php');//has session_start()


function query_types() {
	
$cats = array('Food','Snacks','Drinks','Transpo','Luho','Books/Mags','DVD','Movies','Clothes','Load','Loan','Hotel');
sort($cats);
return $cats;
}

?>
<br>
<form action="result.php" method="post">

	Type <select name="category">
<?php 
	$x = query_types();
	foreach($x as $cat) {
		echo '<option value="'.$cat.'">'.$cat.'</option>';
	}
?>
	<option value="all">all</option>
	
	</select>
	
	<br> date start (y-m-d)<input name="date-start">
	<br> date end (y-m-d) <input name="date-end">
	<input type="submit" name="submit" value="calculate">

</form>