<?php
session_start();

/*
http://mobiforge.com/developing/story/lightweight-device-detection-php
*/
 
$mobile_browser = '0';
 
if (preg_match('/(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone|android)/i', strtolower($_SERVER['HTTP_USER_AGENT']))) {
    $mobile_browser++;
}
 
if ((strpos(strtolower($_SERVER['HTTP_ACCEPT']),'application/vnd.wap.xhtml+xml') > 0) or ((isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE'])))) {
    $mobile_browser++;
}    
 
$mobile_ua = strtolower(substr($_SERVER['HTTP_USER_AGENT'], 0, 4));
$mobile_agents = array(
    'w3c ','acs-','alav','alca','amoi','audi','avan','benq','bird','blac',
    'blaz','brew','cell','cldc','cmd-','dang','doco','eric','hipt','inno',
    'ipaq','java','jigs','kddi','keji','leno','lg-c','lg-d','lg-g','lge-',
    'maui','maxo','midp','mits','mmef','mobi','mot-','moto','mwbp','nec-',
    'newt','noki','oper','palm','pana','pant','phil','play','port','prox',
    'qwap','sage','sams','sany','sch-','sec-','send','seri','sgh-','shar',
    'sie-','siem','smal','smar','sony','sph-','symb','t-mo','teli','tim-',
    'tosh','tsm-','upg1','upsi','vk-v','voda','wap-','wapa','wapi','wapp',
    'wapr','webc','winw','winw','xda ','xda-');
 
if (in_array($mobile_ua,$mobile_agents)) {
    $mobile_browser++;
}
 /*
if (strpos(strtolower($_SERVER['ALL_HTTP']),'OperaMini') > 0) {
    $mobile_browser++;
}
 */
if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'windows') > 0) {
    $mobile_browser = 0;
} else {
   $mobile_browser = 1;
}
 



if(!isset($_SESSION['unr'])) {
	//not logged in view:
	
	echo '<!doctype html>';
	echo '<html><head>';
	if ($mobile_browser > 0) {
   // do something
	   
		echo '<title>EXPENSES by jpalala</title>';
		echo '<meta name="viewport" content="width=device-width, initial-scale=1">'; 
		echo '<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0.1/jquery.mobile-1.0.1.min.css" />';
	
		echo '<script src="http://code.jquery.com/jquery-1.6.4.min.js"></script>';
		echo '<script src="http://code.jquery.com/mobile/1.0.1/jquery.mobile-1.0.1.min.js"></script><style type="text/css">font-size:11px;</style>';
		echo '</head>';	
		echo '<body>';
		echo '<div data-role="page">';
/*
		if(strpos($_SERVER["SCRIPT_NAME"],'index.php')) {
			echo '<div data-role="header" data-position="inline"><h1>Login</h1></div>';
		}
*/
		echo '<form action="login.php" method="post">';
		echo 'user:<input name="uname" type="text" value="joe" placeholder="username"><br />';
		echo 'pass:<input name="password" type="password" value="" placeholder="password"><br />';
		echo '<input type="submit" name="sub" value="Login">';
		echo '</form></div></body></html>';
	} else {
		
		echo '<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE9"/>';
		echo '<title>EXPENSES by jpalala</title>';
		echo '<link rel="stylesheet" type="text/css" href="exp_minimal.css">';
		echo '<style type="text/css"> form { top:15%; position:absolute;}</style>';
		echo '</head>';
	
		echo '<body>';
		
		echo '<div data-role="page">';
		echo '<form action="login.php" method="post">';
		echo "<h1>LOGIN</h1>";
		echo '<table><tr><td>Username</td><td><input name="uname" type="hidden" value="';
		
		if(isset($_POST['uname'])) {
			echo "jose"; //$_POST['uname']; 
		} else  { 
			echo "jose"; 
		} 
		
		echo '"> </td></tr>';
		echo '<tr><td>Password
			</td><td><input name="password" type="password" value=""></td></tr>';
		echo "\r\n";
		echo "<tr><td colspan=\"2\" align=\"center\"><input type=\"submit\" name=\"sub\" value=\"Login\"></td></tr>\r\n";
		echo '</table></form></body></html>';
		exit();
	}
} else {

	//logged in view:
	echo '<!doctype html>
	<html><head>';

	echo '<meta name="viewport" content="width=device-width, initial-scale=1"> 
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.0.1/jquery.mobile-1.0.1.min.css" />';
	echo '<title>pitchapie expenses</title>';
	echo '<script src="http://code.jquery.com/jquery-1.6.4.min.js"></script>
	<script src="http://code.jquery.com/mobile/1.0.1/jquery.mobile-1.0.1.min.js"></script>';
/*
else {
   // do something else
   echo '<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE9" />';
   echo '<link rel="stylesheet" type="text/css" href="exp_minimal.css">';
   	echo '<title>pitchapie expenses</title>';
} 
*/  
echo '</head>';
echo '<body>';
echo '<div data-role="page">';
echo '<div data-role="header" data-position="inline"><h1>';
echo "Welcome";
echo '</h1></div>';
echo '<div data-role="navbar" id="navbar"> ';
echo '<ul><li><a href="index.php">Back</a></li>';
 
 echo '<li><a href="add.php">Add</a></li>';

if($mobile_browser > 0) {
	echo '<li><a href="logout.php">Exit</a></li>'; 
} else {
	echo '<li><a href="logout.php">Log off</a></li>'; 
	echo '<li><a href="dl.php?c=1">CSV</a></li>' ;

	echo '<li><a href="budget.txt">budget.txt</li>';
	echo '<li><a href="dl.php">Download</a></li>';

}


echo '</ul>';
echo '</div>';


}
?>
