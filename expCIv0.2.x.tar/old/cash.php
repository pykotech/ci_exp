<?php
session_start();
if(!isset($_SESSION['unr'])) { header('Location: index.php'); exit(); }
?>
<!doctype html>
<?php

include('db.php');

$rs = $db->query("SELECT * FROM cash_on_hand ORDER BY modified DESC"); 

if($rs)
{
	while($rows = $rs->fetch_object())
	{
        echo "<h1>on hand" .$rows->modified . "</h1>";
        echo "<strong>" . $rows->amount . "</strong>";
	}
}
else 
{
	echo "No Records"; 

} 

$rs->free_result();

$rs = $db->query("SELECT * FROM cash_bank ORDER BY modified DESC"); 

if($rs)
{
	while($rows = $rs->fetch_object())
	{
        echo "<strong style=\"font-size:14px;\">on hand" .$rows->bank   . "</strong> : ";
        echo "<strong>" . $rows->amount . "</strong><br />";
	}
}
else 
{
	echo "No Records"; 

} 

$rs->free_result();



$conn->close();
include('foot.php');
?>
